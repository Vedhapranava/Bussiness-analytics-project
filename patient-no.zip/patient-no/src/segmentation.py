from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans

from src.features import engineer_features
from src.loaders import load_raw


@dataclass
class SegmentationResult:
    patient_df: pd.DataFrame
    kmeans: KMeans
    summary: pd.DataFrame


def build_patient_level_table(df_feat: pd.DataFrame | None = None) -> pd.DataFrame:
    """Aggregate engineered appointment-level features to patient level."""
    if df_feat is None:
        raw = load_raw()
        df_feat = engineer_features(raw)

    # We expect patientid to be preserved by engineer_features
    if "patientid" not in df_feat.columns:
        raise KeyError(
            "Expected 'patientid' in engineered features for segmentation."
        )

    grouped = (
        df_feat.groupby("patientid")
        .agg(
            num_appointments=("no_show", "size"),
            num_noshows=("no_show", "sum"),
            mean_lead_time_days=("lead_time_days", "mean"),
            mean_prior_noshow_rate=("prior_noshow_rate", "mean"),
            mean_comorbidity=("comorbidity_count", "mean"),
            mean_age=("age", "mean"),
        )
        .reset_index()
    )
    grouped["no_show_rate"] = (
        grouped["num_noshows"] / grouped["num_appointments"]
    )
    return grouped


def run_kmeans(
    patient_df: pd.DataFrame, n_clusters: int = 3, random_state: int = 42
) -> SegmentationResult:
    """Cluster patients into behavioral segments."""
    features = patient_df[
        [
            "num_appointments",
            "no_show_rate",
            "mean_lead_time_days",
            "mean_prior_noshow_rate",
            "mean_comorbidity",
            "mean_age",
        ]
    ].fillna(0.0)

    # Simple standardization (z-score)
    means = features.mean()
    stds = features.std().replace(0, 1.0)
    X = (features - means) / stds

    kmeans = KMeans(
        n_clusters=n_clusters, random_state=random_state, n_init=10
    )
    labels = kmeans.fit_predict(X)

    patient_df = patient_df.copy()
    patient_df["segment"] = labels

    summary = (
        patient_df.groupby("segment")
        .agg(
            num_patients=("patientid", "nunique"),
            avg_appointments=("num_appointments", "mean"),
            avg_no_show_rate=("no_show_rate", "mean"),
            avg_lead_time=("mean_lead_time_days", "mean"),
            avg_comorbidity=("mean_comorbidity", "mean"),
        )
        .reset_index()
    )

    return SegmentationResult(
        patient_df=patient_df, kmeans=kmeans, summary=summary
    )
