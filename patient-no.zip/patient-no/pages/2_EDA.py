import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import plotly.express as px

from imblearn.over_sampling import SMOTE  # pip install imbalanced-learn

from src.loaders import load_raw
from src.features import engineer_features
from src.train import CORE_FEATURES

st.title("📊 Exploratory Data Analysis")

df_raw = load_raw()
df_feat = engineer_features(df_raw)

st.write("Raw dataset shape:", df_raw.shape)
st.write("Engineered dataset shape:", df_feat.shape)

# Tabs for structured EDA
tab_dist, tab_rel, tab_feat, tab_smote = st.tabs(
    ["📦 Distributions", "🔗 Relationships", "📐 Feature Analysis", "⚖️ SMOTE Analysis"]
)

# =========================
# Distributions
# =========================
with tab_dist:
    st.subheader("Class Balance (Original Data)")
    vc = df_raw["no_show"].value_counts().rename({0: "Show", 1: "No-Show"})
    fig = px.bar(
        x=["Show", "No-Show"],
        y=[vc.get(0, 0), vc.get(1, 0)],
        labels={"x": "Class", "y": "Count"},
    )
    st.plotly_chart(fig, use_container_width=True)

    st.subheader("Numeric Feature Distribution")
    num_cols = df_feat.select_dtypes(include=["number"]).columns.tolist()
    if "no_show" in num_cols:
        num_cols.remove("no_show")
    if not num_cols:
        st.info("No numeric features available.")
    else:
        feature_name = st.selectbox("Select numerical feature", num_cols)
        fig2 = px.histogram(
            df_feat,
            x=feature_name,
            nbins=40,
            marginal="box",
            title=f"Distribution of {feature_name}",
        )
        st.plotly_chart(fig2, use_container_width=True)

    st.subheader("Top 15 Neighbourhoods by Appointment Volume")
    if "neighbourhood" in df_raw.columns:
        nh = df_raw["neighbourhood"].value_counts().head(15)
        fig3 = px.bar(
            x=nh.index,
            y=nh.values,
            labels={"x": "Neighbourhood", "y": "Appointments"},
        )
        fig3.update_layout(xaxis_tickangle=-45)
        st.plotly_chart(fig3, use_container_width=True)
    else:
        st.info("Neighbourhood column not found in raw data.")

# =========================
# Relationships
# =========================
with tab_rel:
    st.subheader("No-Show Rate by Weekday")
    if "appointment_date" in df_raw.columns:
        df_raw["appointment_date"] = pd.to_datetime(df_raw["appointment_date"])
        df_raw["weekday"] = df_raw["appointment_date"].dt.day_name()
        weekday_stats = (
            df_raw.groupby("weekday")["no_show"]
            .mean()
            .reindex(
                ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
            )
        )
        fig4 = px.bar(
            x=weekday_stats.index,
            y=weekday_stats.values,
            labels={"x": "Weekday", "y": "No-Show Rate"},
        )
        st.plotly_chart(fig4, use_container_width=True)
    else:
        st.info("appointment_date column not found.")

    st.subheader("Appointments by Hour of Day")
    if "appointment_hour" in df_raw.columns:
        hour_counts = df_raw["appointment_hour"].value_counts().sort_index()
        fig5 = px.bar(
            x=hour_counts.index,
            y=hour_counts.values,
            labels={"x": "Appointment Hour", "y": "Count"},
        )
        st.plotly_chart(fig5, use_container_width=True)
    else:
        st.info("appointment_hour column not found.")

# =========================
# Feature Analysis (Correlation)
# =========================
with tab_feat:
    st.subheader("Correlation Heatmap (Engineered Numeric Features)")
    num = df_feat.select_dtypes(include=["number"]).copy()
    if "no_show" in num.columns:
        cols = [c for c in num.columns if c != "no_show"] + ["no_show"]
        num = num[cols]

    if not num.empty:
        corr = num.corr().fillna(0)
        fig6, ax6 = plt.subplots(figsize=(8, 6))
        im = ax6.imshow(corr, cmap="coolwarm", aspect="auto", vmin=-1, vmax=1)
        ax6.set_xticks(range(len(corr.columns)))
        ax6.set_yticks(range(len(corr.columns)))
        ax6.set_xticklabels(corr.columns, rotation=90)
        ax6.set_yticklabels(corr.columns)
        for i in range(len(corr.columns)):
            for j in range(len(corr.columns)):
                ax6.text(
                    j,
                    i,
                    f"{corr.iloc[i, j]:.2f}",
                    ha="center",
                    va="center",
                    fontsize=7,
                    color="black",
                )
        ax6.set_title("Correlation Matrix")
        fig6.colorbar(im, ax=ax6, fraction=0.046, pad=0.04)
        st.pyplot(fig6, clear_figure=True)
        st.caption("Features with |correlation| > 0.7 may indicate multicollinearity.")
    else:
        st.info("No numeric columns for correlation analysis.")

# =========================
# SMOTE Analysis
# =========================
with tab_smote:
    st.subheader("Class Imbalance & SMOTE Analysis")

    # Original balance
    orig_counts = df_feat["no_show"].value_counts().sort_index()
    orig_df = pd.DataFrame(
        {
            "class": ["Show", "No-Show"],
            "count": [orig_counts.get(0, 0), orig_counts.get(1, 0)],
            "type": "Original",
        }
    )

    # Apply SMOTE on core features
    X = df_feat[CORE_FEATURES].replace([np.inf, -np.inf], np.nan).fillna(0)
    y = df_feat["no_show"].astype(int)
    smote = SMOTE(random_state=42)
    X_res, y_res = smote.fit_resample(X, y)
    res_counts = pd.Series(y_res).value_counts().sort_index()
    res_df = pd.DataFrame(
        {
            "class": ["Show", "No-Show"],
            "count": [res_counts.get(0, 0), res_counts.get(1, 0)],
            "type": "After SMOTE",
        }
    )

    plot_df = pd.concat([orig_df, res_df], ignore_index=True)
    fig7 = px.bar(
        plot_df,
        x="class",
        y="count",
        color="type",
        barmode="group",
        labels={"class": "Class", "count": "Count"},
        title="Class Distribution Before and After SMOTE",
    )
    st.plotly_chart(fig7, use_container_width=True)

    st.write("Original counts:", orig_counts.to_dict())
    st.write("After SMOTE counts:", res_counts.to_dict())
    st.caption(
        "SMOTE synthetically increases the minority class so the classifier does not get biased towards the majority class."
    )
