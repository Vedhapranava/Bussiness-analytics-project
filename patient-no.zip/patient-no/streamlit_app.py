import streamlit as st
from src.loaders import load_raw

st.set_page_config(
    page_title="Medical No-Show Prediction",
    page_icon="📅",
    layout="wide",
)

st.title("📅 Medical Appointment No-Show — Dashboard")

st.markdown(
    """
Use the left sidebar pages:

1. **Overview** – preview & dataset quick stats  
2. **EDA** – distributions, correlations, neighbourhoods  
3. **Modeling** – train 3 models, pick best, curves & metrics  
4. **Live Predict** – enter details → real-time probability  
5. **Time-Series** – ARIMA / SARIMA forecasts of volume & no-shows  
6. **Business Analytics** – KPIs, neighbourhood risk, segmentation  
7. **Gemini Assist** – model explanation & decision suggestions
"""
)

if st.button("Load & Preview"):
    df = load_raw()
    st.success(f"Loaded {len(df):,} rows × {len(df.columns)} columns")
    st.dataframe(df.head(20), use_container_width=True)
