from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, Optional

import numpy as np
import pandas as pd
from statsmodels.tsa.seasonal import STL
from statsmodels.tsa.statespace.sarimax import SARIMAX

from src.loaders import load_raw


Metric = Literal[
    "no_show_count", "show_count", "total_appointments", "no_show_rate"
]
ModelType = Literal["ARIMA", "SARIMA"]


@dataclass
class ForecastResult:
    history: pd.Series
    forecast: pd.Series
    conf_int: pd.DataFrame
    model_summary: str


@dataclass
class DecompositionResult:
    trend: pd.Series
    seasonal: pd.Series
    resid: pd.Series


def _build_daily_counts(df: pd.DataFrame, metric: Metric) -> pd.Series:
    """Aggregate raw appointment data into a daily metric series."""
    if "appointment_date" not in df.columns:
        if "appointment_day" not in df.columns:
            raise KeyError(
                "Expected 'appointment_day' or 'appointment_date' in dataframe."
            )
        df = df.copy()
        df["appointment_date"] = df["appointment_day"].dt.normalize()

    date_index = df["appointment_date"]

    total = df.groupby(date_index).size().rename("total_appointments")
    noshow = df.groupby(date_index)["no_show"].sum().rename("no_shows")
    show = (total - noshow).rename("shows")

    if metric == "no_show_count":
        series = noshow
    elif metric == "show_count":
        series = show
    elif metric == "total_appointments":
        series = total
    elif metric == "no_show_rate":
        rate = noshow / total.replace(0, np.nan)
        series = rate.fillna(0.0).rename("no_show_rate")
    else:
        raise ValueError(f"Unknown metric: {metric}")

    # Fill missing dates for proper time series
    series = series.sort_index()
    full_range = pd.date_range(series.index.min(), series.index.max(), freq="D")
    series = series.reindex(full_range).fillna(0.0)
    series.index.name = "date"
    return series.astype(float)


def build_daily_series(metric: Metric = "no_show_count") -> pd.Series:
    """Public helper: load raw data and build daily metric series."""
    df = load_raw()
    return _build_daily_counts(df, metric=metric)


def forecast_series(
    metric: Metric = "no_show_count",
    model_type: ModelType = "SARIMA",
    order: tuple[int, int, int] = (1, 1, 1),
    seasonal_order: Optional[tuple[int, int, int, int]] = (1, 1, 1, 7),
    steps: int = 14,
) -> ForecastResult:
    """High-level helper: build series, fit SARIMAX, and forecast horizon."""
    series = build_daily_series(metric=metric)
    if not isinstance(series.index, pd.DatetimeIndex):
        series.index = pd.to_datetime(series.index)

    series = series.asfreq("D").fillna(0.0)

    if model_type == "ARIMA":
        seasonal = None
    else:
        seasonal = seasonal_order

    model = SARIMAX(
        series,
        order=order,
        seasonal_order=seasonal or (0, 0, 0, 0),
        enforce_stationarity=False,
        enforce_invertibility=False,
    )
    fitted = model.fit(disp=False)

    fc = fitted.get_forecast(steps=steps)
    forecast = fc.predicted_mean
    conf_int = fc.conf_int()

    return ForecastResult(
        history=series,
        forecast=forecast,
        conf_int=conf_int,
        model_summary=str(fitted.summary()),
    )


def decompose_series(
    metric: Metric = "no_show_count", period: int = 7
) -> DecompositionResult:
    """Return STL decomposition of the daily series for BA plots."""
    series = build_daily_series(metric=metric)
    if not isinstance(series.index, pd.DatetimeIndex):
        series.index = pd.to_datetime(series.index)

    series = series.asfreq("D").fillna(0.0)

    stl = STL(series, period=period, robust=True)
    res = stl.fit()

    return DecompositionResult(
        trend=res.trend,
        seasonal=res.seasonal,
        resid=res.resid,
    )
