import streamlit as st
import matplotlib.pyplot as plt

from src.time_series import forecast_series, decompose_series

st.title("📈 Time-Series Forecasting — No-Show & Volume")

metric = st.selectbox(
    "Select metric to forecast",
    options=["no_show_count", "total_appointments", "no_show_rate", "show_count"],
    index=0,
)

model_type = st.radio(
    "Model type",
    options=["SARIMA", "ARIMA"],
    index=0,
    horizontal=True,
)

steps = st.slider(
    "Forecast horizon (days)", min_value=7, max_value=60, value=14, step=7
)

with st.expander("Advanced model settings", expanded=False):
    p = st.number_input("p (AR order)", 0, 5, 1)
    d = st.number_input("d (diff order)", 0, 2, 1)
    q = st.number_input("q (MA order)", 0, 5, 1)
    sp = st.number_input("Seasonal P", 0, 3, 1)
    sd = st.number_input("Seasonal D", 0, 2, 1)
    sq = st.number_input("Seasonal Q", 0, 3, 1)
    s = st.number_input("Seasonal period (e.g. 7=weekly)", 1, 60, 7)

run = st.button("🚀 Run forecast")

if run:
    try:
        with st.spinner("Fitting model and forecasting..."):
            result = forecast_series(
                metric=metric,
                model_type=model_type,
                order=(p, d, q),
                seasonal_order=(sp, sd, sq, s),
                steps=steps,
            )
    except Exception as e:
        st.error(f"Error during forecasting: {e}")
        st.stop()

    st.subheader("📊 History + Forecast")

    hist = result.history
    fc = result.forecast
    ci = result.conf_int

    fig, ax = plt.subplots(figsize=(10, 4))
    ax.plot(hist.index, hist.values, label="History")
    ax.plot(fc.index, fc.values, label="Forecast", linestyle="--")
    if ci is not None:
        ax.fill_between(
            fc.index,
            ci.iloc[:, 0].values,
            ci.iloc[:, 1].values,
            alpha=0.2,
            label="Confidence interval",
        )
    ax.set_xlabel("Date")
    ax.set_ylabel(metric)
    ax.legend()
    st.pyplot(fig, clear_figure=True)

    st.subheader("🔍 Decomposition (Trend / Seasonality / Residual)")
    try:
        decomp = decompose_series(metric=metric, period=int(s))
    except Exception as e:
        st.error(f"Error during decomposition: {e}")
    else:
        fig2, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(10, 8), sharex=True)
        ax1.plot(decomp.trend.index, decomp.trend.values)
        ax1.set_ylabel("Trend")
        ax2.plot(decomp.seasonal.index, decomp.seasonal.values)
        ax2.set_ylabel("Seasonal")
        ax3.plot(decomp.resid.index, decomp.resid.values)
        ax3.set_ylabel("Residual")
        ax3.set_xlabel("Date")
        st.pyplot(fig2, clear_figure=True)

    with st.expander("Model summary (technical)", expanded=False):
        st.text(result.model_summary)
else:
    st.info("Set options and click **Run forecast** to see ARIMA/SARIMA-based predictions.")
