import streamlit as st
import matplotlib.pyplot as plt
import pandas as pd

from src.loaders import load_raw
from src.features import engineer_features
from src.ba_insights import (
    compute_kpis,
    weekday_hour_matrix,
    neighbourhood_risk_table,
    monthly_trends,
    patient_behavior_summary,
)
from src.segmentation import build_patient_level_table, run_kmeans

st.title("📊 Business Analytics — Appointment & No-Show Insights")

with st.spinner("Loading data and engineering features..."):
    df = load_raw()
    df_feat = engineer_features(df)

# ---------------- KPIs ----------------
st.subheader("Key Metrics")

kpis = compute_kpis(df)
c1, c2, c3, c4 = st.columns(4)
c1.metric("Total appointments", f"{kpis['total_appointments']:,}")
c2.metric("No-shows", f"{kpis['no_shows']:,}")
c3.metric("No-show rate", f"{kpis['no_show_rate']*100:.1f}%")
if kpis.get("avg_lead_time_days") is not None:
    c4.metric("Avg. lead time (days)", f"{kpis['avg_lead_time_days']:.1f}")
else:
    c4.metric("Avg. lead time (days)", "N/A")

# ---------------- Weekday-Hour heatmap ----------------
st.subheader("Weekday × Hour no-show pattern")

wh = weekday_hour_matrix(df)
st.caption("mean_*=no-show rate, count_*=number of appointments")
st.dataframe(wh, use_container_width=True)

# ---------------- Monthly trends ----------------
st.subheader("Monthly trends")

mt = monthly_trends(df)
if not mt.empty:
    fig_mt, ax_mt = plt.subplots(figsize=(8, 4))
    ax_mt.plot(mt["month"], mt["total_appointments"], label="Total appointments")
    ax_mt.plot(mt["month"], mt["no_shows"], label="No-shows")
    ax_mt.set_xlabel("Month")
    ax_mt.set_ylabel("Count")
    ax_mt.legend()
    plt.xticks(rotation=45)
    st.pyplot(fig_mt, clear_figure=True)

    fig_rate, ax_rate = plt.subplots(figsize=(8, 3))
    ax_rate.plot(mt["month"], mt["no_show_rate"] * 100.0, marker="o")
    ax_rate.set_xlabel("Month")
    ax_rate.set_ylabel("No-show rate (%)")
    plt.xticks(rotation=45)
    st.pyplot(fig_rate, clear_figure=True)
else:
    st.info("Not enough data to compute monthly trends.")

# ---------------- Neighbourhood risk table ----------------
st.subheader("Neighbourhood risk (filtered by minimum volume)")

min_appts = st.slider("Minimum appointments per neighbourhood", 10, 300, 50, 10)
nrisk = neighbourhood_risk_table(df, min_appointments=min_appts)
st.dataframe(nrisk, use_container_width=True)

# ---------------- Patient behaviour summary ----------------
st.subheader("Patient behaviour distribution (engineered features)")

pbs = patient_behavior_summary(df_feat)
if pbs:
    pb_df = pd.DataFrame(pbs).T
    st.dataframe(pb_df, use_container_width=True)
else:
    st.info("Could not compute behaviour summary from engineered features.")

# ---------------- Segmentation ----------------
st.subheader("Patient segments (behavioural clustering)")

try:
    patient_df = build_patient_level_table(df_feat)
    n_clusters = st.slider("Number of segments", 2, 6, 3, 1)
    seg_result = run_kmeans(patient_df, n_clusters=n_clusters)

    st.write("Segment-wise summary:")
    st.dataframe(seg_result.summary, use_container_width=True)

    st.write("Sample of patient-level segmentation (head):")
    st.dataframe(seg_result.patient_df.head(50), use_container_width=True)

except KeyError as e:
    st.warning(f"Segmentation could not be run: {e}")
except Exception as e:
    st.error(f"Unexpected error during segmentation: {e}")
