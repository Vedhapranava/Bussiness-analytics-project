from __future__ import annotations
from pathlib import Path

import joblib
import pandas as pd

from src.train import CORE_FEATURES, MODEL_PATH
from src.loaders import load_raw


def _neighbourhood_freq_map(df: pd.DataFrame) -> dict:
    if "neighbourhood" not in df.columns:
        return {}
    return df["neighbourhood"].value_counts(dropna=False).to_dict()


def build_feature_row(
    *,
    age: float,
    sms_received: int,
    hypertension: int,
    diabetes: int,
    alcoholism: int,
    handicap: int,
    scheduled_dt: pd.Timestamp,
    appointment_dt: pd.Timestamp,
    prior_appointments: int,
    prior_noshows: int,
    days_since_last_appt: float,
    neighbourhood: str | None = None,
    ref_df: pd.DataFrame | None = None,
) -> pd.DataFrame:
    """Build a single-row dataframe in CORE_FEATURES order for live prediction."""
    lead_time_days = max(
        0,
        int((appointment_dt.normalize() - scheduled_dt.normalize()).days),
    )
    comorbidity_count = int(
        hypertension + diabetes + alcoholism + handicap
    )
    risk_score = (
        hypertension * 0.6
        + diabetes * 0.6
        + alcoholism * 0.3
        + handicap * 0.4
        + (0.5 if age >= 60 else 0.0)
    )
    risk_x_leadtime = risk_score * lead_time_days

    prior_appointments = max(0, int(prior_appointments))
    prior_noshows = max(0, int(prior_noshows))
    prior_noshow_rate = (
        0.0
        if prior_appointments == 0
        else prior_noshows / prior_appointments
    )

    # neighbourhood frequency lookup
    neigh_freq = 0
    if ref_df is None:
        try:
            ref_df = load_raw()
        except Exception:
            ref_df = None
    if (
        ref_df is not None
        and neighbourhood
        and "neighbourhood" in ref_df.columns
    ):
        freq_map = _neighbourhood_freq_map(ref_df)
        neigh_freq = int(freq_map.get(neighbourhood, 0))

    row = pd.DataFrame(
        [
            {
                "lead_time_days": lead_time_days,
                "sms_received": int(sms_received),
                "prior_noshow_rate": float(prior_noshow_rate),
                "days_since_last_appt": float(max(0, days_since_last_appt)),
                "comorbidity_count": int(comorbidity_count),
                "age": float(age),
                "neighbourhood_freq": int(neigh_freq),
                "risk_x_leadtime": float(risk_x_leadtime),
            }
        ]
    )

    # Ensure order
    for c in CORE_FEATURES:
        if c not in row.columns:
            row[c] = 0
    return row[CORE_FEATURES]


def load_best_model(path: str | Path | None = None):
    p = Path(path) if path else Path(MODEL_PATH)
    if not p.exists():
        raise FileNotFoundError(f"Best model not found at: {p}")
    return joblib.load(p)


def predict_proba_single(features_row: pd.DataFrame, model=None) -> float:
    """Return probability of no-show for a single row."""
    mdl = model or load_best_model()
    if hasattr(mdl, "predict_proba"):
        return float(mdl.predict_proba(features_row)[:, 1][0])
    # fallback (rare)
    scores = mdl.decision_function(features_row)
    scores = (scores - scores.min()) / (
        scores.max() - scores.min() + 1e-9
    )
    return float(scores[0])
