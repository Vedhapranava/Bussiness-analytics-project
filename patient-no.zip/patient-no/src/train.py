from pathlib import Path
import numpy as np
import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
)

# Where the best model will be saved
PROCESSED_DIR = Path(__file__).resolve().parents[1] / "data" / "processed"
MODEL_PATH = PROCESSED_DIR / "best_model.pkl"

# Feature order expected by the model
CORE_FEATURES = [
    "lead_time_days",
    "sms_received",
    "prior_noshow_rate",
    "days_since_last_appt",
    "comorbidity_count",
    "age",
    "neighbourhood_freq",
    "risk_x_leadtime",
]


def _eval(model, Xte, yte):
    """Return a dict of metrics. Supports models with/without predict_proba."""
    if hasattr(model, "predict_proba"):
        proba = model.predict_proba(Xte)[:, 1]
    elif hasattr(model, "decision_function"):
        scores = model.decision_function(Xte)
        # Min-max normalise to [0, 1] for AUC calculations
        proba = (scores - scores.min()) / (scores.max() - scores.min() + 1e-9)
    else:
        # Fallback – treat predictions as scores
        proba = model.predict(Xte)

    pred = (proba >= 0.5).astype(int)

    return {
        "accuracy": round(accuracy_score(yte, pred), 4),
        "precision": round(precision_score(yte, pred, zero_division=0), 4),
        "recall": round(recall_score(yte, pred, zero_division=0), 4),
        "f1": round(f1_score(yte, pred, zero_division=0), 4),
        "auc": round(roc_auc_score(yte, proba), 4),
        "confusion_matrix": confusion_matrix(yte, pred).tolist(),
    }


def train_models(df: pd.DataFrame):
    """Train several models and return metrics + best model name + fitted models.

    Returns
    -------
    results : dict
        {model_name: metrics_dict}
    best_name : str
        Name of the model with highest AUC.
    fitted : dict
        {model_name: trained_estimator}
    """
    missing = [c for c in CORE_FEATURES + ["no_show"] if c not in df.columns]
    if missing:
        raise KeyError(f"Engineered dataset missing columns: {missing}")

    X = df[CORE_FEATURES].replace([np.inf, -np.inf], np.nan).fillna(0)
    y = df["no_show"].astype(int).values

    Xtr, Xte, ytr, yte = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=42
    )

    models = {
        "logistic_regression": LogisticRegression(max_iter=2000, solver="lbfgs"),
        "knn": KNeighborsClassifier(n_neighbors=15),
        "decision_tree": DecisionTreeClassifier(
            max_depth=None, min_samples_split=2, random_state=42
        ),
        "random_forest": RandomForestClassifier(
            n_estimators=400, random_state=42, n_jobs=-1
        ),
        "gradient_boosting": GradientBoostingClassifier(random_state=42),
        "mlp": MLPClassifier(
            hidden_layer_sizes=(64, 32),
            max_iter=300,
            random_state=42,
        ),
    }

    results: dict[str, dict] = {}
    fitted: dict[str, object] = {}
    for name, mdl in models.items():
        mdl.fit(Xtr, ytr)
        fitted[name] = mdl
        results[name] = _eval(mdl, Xte, yte)

    # Pick best by AUC
    best_name = max(results.items(), key=lambda kv: kv[1]["auc"])[0]
    best_model = fitted[best_name]

    # Save best model
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump(best_model, MODEL_PATH)
    results[best_name]["saved_to"] = str(MODEL_PATH)

    return results, best_name, fitted
