import streamlit as st
import pandas as pd

from src.loaders import load_raw

st.title("🧾 Overview")

# Load data safely
try:
    df = load_raw()
    st.success(f"Loaded {len(df):,} rows × {len(df.columns)} columns")
except Exception as e:
    st.error(f"Error loading dataset: {e}")
    st.stop()

st.subheader("Preview")
st.dataframe(df.head(30), use_container_width=True)

st.subheader("Quick Stats")
c1, c2, c3 = st.columns(3)
c1.metric("Rows", f"{len(df):,}")
c2.metric("Columns", f"{len(df.columns)}")
c3.metric(
    "Invalid date rows",
    int(df.get("invalid_date_flag", 0).sum())
    if "invalid_date_flag" in df.columns
    else 0,
)

if "no_show" in df.columns:
    st.subheader("Target Distribution (0=Show, 1=No-Show)")
    st.bar_chart(df["no_show"].value_counts().sort_index())
else:
    st.info("Column `no_show` not found in the dataset.")
