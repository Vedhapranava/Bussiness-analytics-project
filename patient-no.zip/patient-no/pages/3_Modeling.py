import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import plotly.express as px
import plotly.graph_objects as go

from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_curve, auc, precision_recall_curve, confusion_matrix

from src.loaders import load_raw
from src.features import engineer_features
from src.train import train_models, CORE_FEATURES, MODEL_PATH

st.title("🤖 Modeling & Evaluation")

# Load & engineer once
df_raw = load_raw()
df_feat = engineer_features(df_raw)

st.write("**Training features (order matters):**", CORE_FEATURES)
st.write("Engineered dataset shape:", df_feat.shape)

if "no_show" not in df_feat.columns:
    st.error("`no_show` column missing in engineered features. Please check feature engineering.")
    st.stop()

if st.button("🚀 Train models and pick the best"):
    with st.spinner("Training models..."):
        results, best_name, fitted = train_models(df_feat)

    # Prepare metrics dataframe (drop confusion_matrix for plotting)
    metrics_df = pd.DataFrame(results).T
    if "confusion_matrix" in metrics_df.columns:
        metrics_df_no_cm = metrics_df.drop(columns=["confusion_matrix"])
    else:
        metrics_df_no_cm = metrics_df.copy()

    st.success(f"Best model by AUC: **{best_name}** (saved to `{MODEL_PATH}`)")
    st.subheader("📊 Test Metrics Table")

    # --- FIX: format only numeric columns, not strings like 'saved_to' ---
    float_cols = metrics_df_no_cm.select_dtypes(include=["float", "int"]).columns
    st.dataframe(
        metrics_df_no_cm.style.format({col: "{:.4f}" for col in float_cols}),
        use_container_width=True,
    )

    # Nice display names
    name_map = {
        "logistic_regression": "Logistic Regression",
        "knn": "KNN",
        "decision_tree": "Decision Tree",
        "random_forest": "Random Forest",
        "gradient_boosting": "Gradient Boosting",
        "mlp": "MLP (Neural Network)",
    }
    display_names = [name_map.get(n, n) for n in metrics_df_no_cm.index]

    # Tabs for different visualisations
    tab1, tab2, tab3 = st.tabs(["📈 Accuracy & ROC-AUC", "📋 All Metrics", "🧭 Radar Chart"])

    # -----------------
    # Tab 1: Accuracy & ROC-AUC
    # -----------------
    with tab1:
        st.markdown("### Model Accuracy Comparison")
        fig_acc = px.bar(
            x=display_names,
            y=metrics_df_no_cm["accuracy"],
            labels={"x": "Model", "y": "Accuracy"},
        )
        st.plotly_chart(fig_acc, use_container_width=True)

        st.markdown("### ROC-AUC Score Comparison")
        fig_auc = px.bar(
            x=display_names,
            y=metrics_df_no_cm["auc"],
            labels={"x": "Model", "y": "ROC-AUC"},
        )
        st.plotly_chart(fig_auc, use_container_width=True)

    # -----------------
    # Tab 2: All metrics grouped
    # -----------------
    with tab2:
        st.markdown("### All Metrics Comparison Across Models")
        melt_df = metrics_df_no_cm.reset_index().rename(columns={"index": "model"})
        melt_df["model_display"] = melt_df["model"].map(name_map).fillna(melt_df["model"])
        plot_df = melt_df.melt(
            id_vars=["model", "model_display"],
            value_vars=["accuracy", "precision", "recall", "f1", "auc"],
            var_name="metric",
            value_name="score",
        )
        fig_all = px.bar(
            plot_df,
            x="model_display",
            y="score",
            color="metric",
            barmode="group",
            labels={"model_display": "Model", "score": "Score"},
        )
        st.plotly_chart(fig_all, use_container_width=True)

    # -----------------
    # Tab 3: Radar chart
    # -----------------
    with tab3:
        st.markdown("### Radar Chart (select a model)")
        model_for_radar = st.selectbox(
            "Choose model for radar view:",
            list(metrics_df_no_cm.index),
            format_func=lambda x: name_map.get(x, x),
        )
        row = metrics_df_no_cm.loc[model_for_radar, ["accuracy", "precision", "recall", "f1", "auc"]]
        categories = list(row.index)
        values = row.values.tolist()
        values += values[:1]
        categories_closed = categories + categories[:1]

        fig_radar = go.Figure(
            data=go.Scatterpolar(
                r=values,
                theta=categories_closed,
                fill="toself",
            )
        )
        fig_radar.update_layout(
            polar=dict(radialaxis=dict(visible=True, range=[0, 1])),
            showlegend=False,
        )
        st.plotly_chart(fig_radar, use_container_width=True)

    # -----------------
    # Model selection explanation
    # -----------------
    st.subheader("🏆 Model Selection Summary")
    best_row = metrics_df_no_cm.loc[best_name]
    st.markdown(
        f"""**Selected model:** `{name_map.get(best_name, best_name)}`  
- Accuracy: **{best_row['accuracy']:.4f}**  
- Precision: **{best_row['precision']:.4f}**  
- Recall: **{best_row['recall']:.4f}**  
- F1-score: **{best_row['f1']:.4f}**  
- ROC-AUC: **{best_row['auc']:.4f}**  
"""
    )

    # -----------------
    # Detailed curves & threshold tuning
    # -----------------
    st.subheader("📉 Detailed Curves & Threshold Tuning")
    model_for_curves = st.selectbox(
        "Select a model for ROC/PR & confusion matrix:",
        list(fitted.keys()),
        index=list(fitted.keys()).index(best_name),
        format_func=lambda x: name_map.get(x, x),
    )
    selected_model = fitted[model_for_curves]

    # Split again to visualise curves
    X = df_feat[CORE_FEATURES].values
    y = df_feat["no_show"].astype(int).values
    Xtr, Xte, ytr, yte = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=42
    )

    # Get probabilities
    if hasattr(selected_model, "predict_proba"):
        proba = selected_model.predict_proba(Xte)[:, 1]
    elif hasattr(selected_model, "decision_function"):
        scores = selected_model.decision_function(Xte)
        proba = (scores - scores.min()) / (scores.max() - scores.min() + 1e-9)
    else:
        proba = selected_model.predict(Xte).astype(float)

    # ROC curve
    st.markdown(f"#### ROC Curve — {name_map.get(model_for_curves, model_for_curves)}")
    fpr, tpr, _ = roc_curve(yte, proba)
    roc_auc = auc(fpr, tpr)
    fig1, ax1 = plt.subplots()
    ax1.plot(fpr, tpr, label=f"AUC = {roc_auc:.3f}")
    ax1.plot([0, 1], [0, 1], "--")
    ax1.set_xlabel("False Positive Rate")
    ax1.set_ylabel("True Positive Rate")
    ax1.legend(loc="lower right")
    st.pyplot(fig1, clear_figure=True)

    # Precision–Recall curve
    st.markdown(f"#### Precision–Recall Curve — {name_map.get(model_for_curves, model_for_curves)}")
    prec, rec, _ = precision_recall_curve(yte, proba)
    fig2, ax2 = plt.subplots()
    ax2.plot(rec, prec)
    ax2.set_xlabel("Recall")
    ax2.set_ylabel("Precision")
    st.pyplot(fig2, clear_figure=True)

    # Threshold tuning
    st.markdown("#### Threshold & Confusion Matrix")
    th = st.slider("Decision threshold", 0.0, 1.0, 0.5, 0.01)
    preds = (proba >= th).astype(int)
    cm = confusion_matrix(yte, preds)
    st.dataframe(
        pd.DataFrame(
            cm,
            index=["Actual 0", "Actual 1"],
            columns=["Pred 0", "Pred 1"],
        ),
        use_container_width=True,
    )

    # Feature importance for tree-based models
    st.subheader("🔍 Feature Importance (tree-based models)")
    if hasattr(selected_model, "feature_importances_"):
        importances = selected_model.feature_importances_
        imp_df = pd.DataFrame(
            {
                "feature": CORE_FEATURES,
                "importance": importances,
            }
        ).sort_values("importance", ascending=False)

        st.bar_chart(imp_df.set_index("feature")[:10])
    else:
        st.info(
            "Feature importance is only available for tree-based models like Decision Tree or Random Forest."
        )

else:
    st.info("Click **Train models and pick the best** to run training and view curves.")
