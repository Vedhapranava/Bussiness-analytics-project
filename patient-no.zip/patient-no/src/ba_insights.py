from __future__ import annotations

import numpy as np
import pandas as pd

from src.loaders import load_raw
from src.features import engineer_features


def compute_kpis(df: pd.DataFrame | None = None) -> dict:
    """Compute high-level KPIs for the BA dashboard."""
    if df is None:
        df = load_raw()

    total_appointments = len(df)
    no_shows = int(df["no_show"].sum())
    no_show_rate = (
        no_shows / total_appointments if total_appointments else 0.0
    )
    show_rate = 1.0 - no_show_rate

    avg_lead_time = float(
        df.get("lead_time_days", pd.Series(dtype=float)).mean() or 0.0
    )

    unique_patients = (
        df["patientid"].nunique() if "patientid" in df.columns else None
    )

    return {
        "total_appointments": total_appointments,
        "no_shows": no_shows,
        "no_show_rate": round(no_show_rate, 4),
        "show_rate": round(show_rate, 4),
        "avg_lead_time_days": round(avg_lead_time, 2),
        "unique_patients": int(unique_patients)
        if unique_patients is not None
        else None,
    }


def weekday_hour_matrix(df: pd.DataFrame | None = None) -> pd.DataFrame:
    """Return a pivot table: weekday × hour with mean no-show rate and counts."""
    if df is None:
        df = load_raw()

    if (
        "appointment_weekday" not in df.columns
        or "appointment_hour" not in df.columns
    ):
        if "appointment_day" not in df.columns:
            raise KeyError(
                "Expected 'appointment_day' or appointment_weekday/hour columns."
            )
        df = df.copy()
        df["appointment_weekday"] = df["appointment_day"].dt.day_name()
        df["appointment_hour"] = df["appointment_day"].dt.hour

    temp = df.copy()
    temp["no_show"] = temp["no_show"].astype(int)

    grouped = temp.pivot_table(
        values="no_show",
        index="appointment_weekday",
        columns="appointment_hour",
        aggfunc=["mean", "count"],
        fill_value=0.0,
    )

    # Flatten multiindex columns: mean_8, count_8 etc.
    grouped.columns = [f"{agg}_{col}" for agg, col in grouped.columns]
    return grouped.sort_index()


def neighbourhood_risk_table(
    df: pd.DataFrame | None = None, min_appointments: int = 50
) -> pd.DataFrame:
    """Return per-neighbourhood stats with no-show rate, filtered by volume."""
    if df is None:
        df = load_raw()

    if "neighbourhood" not in df.columns:
        return pd.DataFrame(
            columns=["neighbourhood", "appointments", "no_show_rate"]
        )

    g = (
        df.groupby("neighbourhood")
        .agg(appointments=("no_show", "size"), no_shows=("no_show", "sum"))
        .reset_index()
    )
    g["no_show_rate"] = g["no_shows"] / g["appointments"]
    g = g[g["appointments"] >= min_appointments]
    g = g.sort_values("no_show_rate", ascending=False).reset_index(drop=True)
    return g


def monthly_trends(df: pd.DataFrame | None = None) -> pd.DataFrame:
    """Aggregate appointments by month with counts and no-show rate."""
    if df is None:
        df = load_raw()

    if "appointment_day" not in df.columns:
        raise KeyError("Expected 'appointment_day' column for monthly trends.")

    temp = df.copy()
    temp["month"] = temp["appointment_day"].dt.to_period("M").astype(str)
    agg = (
        temp.groupby("month")
        .agg(
            total_appointments=("no_show", "size"),
            no_shows=("no_show", "sum"),
        )
        .reset_index()
    )
    agg["no_show_rate"] = agg["no_shows"] / agg["total_appointments"]
    return agg.sort_values("month")


def patient_behavior_summary(df_feat: pd.DataFrame | None = None) -> dict:
    """Return simple stats from engineered features for BA commentary."""
    if df_feat is None:
        raw = load_raw()
        df_feat = engineer_features(raw)

    summary: dict[str, dict[str, float]] = {}
    for col in [
        "prior_noshow_rate",
        "comorbidity_count",
        "lead_time_days",
        "age",
    ]:
        if col in df_feat.columns:
            series = df_feat[col]
            summary[col] = {
                "mean": float(series.mean()),
                "std": float(series.std()),
                "min": float(series.min()),
                "max": float(series.max()),
            }
    return summary
