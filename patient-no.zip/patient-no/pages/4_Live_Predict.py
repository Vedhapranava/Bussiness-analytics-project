import streamlit as st
import pandas as pd
from datetime import date, time

from src.loaders import load_raw
from src.train import CORE_FEATURES, MODEL_PATH
from src.predict import build_feature_row, load_best_model, predict_proba_single

st.title("🔮 Live No-Show Predictor")

# Load reference data for neighbourhood frequency
ref_df = load_raw()
neigh_options = ["(none)"]
if "neighbourhood" in ref_df.columns:
    neigh_options += sorted(ref_df["neighbourhood"].dropna().unique().tolist())

with st.form("live_predict_form"):
    st.subheader("Patient & Appointment Inputs")

    c1, c2, c3 = st.columns(3)
    age = c1.number_input("Age", min_value=0, max_value=110, value=35)
    sms_received = c2.selectbox("SMS Received", options=[0, 1], index=0)
    neighbourhood = c3.selectbox(
        "Neighbourhood (optional)", options=neigh_options, index=0
    )
    neighbourhood = None if neighbourhood == "(none)" else neighbourhood

    c4, c5 = st.columns(2)
    scheduled_date = c4.date_input("Scheduled Date", value=date.today())
    scheduled_time = c5.time_input("Scheduled Time", value=time(9, 0))

    c6, c7 = st.columns(2)
    appt_date = c6.date_input("Appointment Date", value=date.today())
    appt_time = c7.time_input("Appointment Time", value=time(10, 0))

    st.markdown("**Health / History**")
    c8, c9, c10, c11 = st.columns(4)
    hypertension = c8.selectbox("Hypertension", [0, 1], index=0)
    diabetes = c9.selectbox("Diabetes", [0, 1], index=0)
    alcoholism = c10.selectbox("Alcoholism", [0, 1], index=0)
    handicap = c11.selectbox("Handicap", [0, 1], index=0)

    c12, c13, c14 = st.columns(3)
    prior_appointments = c12.number_input("Prior Appointments", min_value=0, value=0)
    prior_noshows = c13.number_input("Prior No-Shows", min_value=0, value=0)
    days_since_last_appt = c14.number_input(
        "Days Since Last Appointment", min_value=0, value=0
    )

    threshold = st.slider(
        "Decision Threshold (probability ≥ threshold ⇒ No-Show)",
        0.0,
        1.0,
        0.5,
        0.01,
    )

    submitted = st.form_submit_button("Predict")

if submitted:
    # Combine date+time directly (they are already date/time objects)
    scheduled_dt = pd.Timestamp.combine(scheduled_date, scheduled_time)
    appt_dt = pd.Timestamp.combine(appt_date, appt_time)

    if appt_dt < scheduled_dt:
        st.warning(
            "⚠️ Appointment datetime is before scheduled datetime. "
            "Lead time will be set to 0."
        )

    row = build_feature_row(
        age=age,
        sms_received=int(sms_received),
        hypertension=int(hypertension),
        diabetes=int(diabetes),
        alcoholism=int(alcoholism),
        handicap=int(handicap),
        scheduled_dt=scheduled_dt,
        appointment_dt=appt_dt,
        prior_appointments=int(prior_appointments),
        prior_noshows=int(prior_noshows),
        days_since_last_appt=float(days_since_last_appt),
        neighbourhood=neighbourhood,
        ref_df=ref_df,
    )

    st.write("**Features fed to model**", row)

    # Load saved best model and score
    try:
        model = load_best_model()
    except FileNotFoundError as e:
        st.error(f"{e}\nPlease train a model first on the Modeling page.")
        st.stop()

    proba = predict_proba_single(row, model=model)
    pred = int(proba >= threshold)

    c1, c2 = st.columns(2)
    c1.metric("Predicted No-Show Probability", f"{proba:.3f}")
    c2.metric("Decision @ Threshold", "No-Show" if pred == 1 else "Show")

    st.caption(f"Model file: `{MODEL_PATH}`  •  Threshold: {threshold:.2f}")
