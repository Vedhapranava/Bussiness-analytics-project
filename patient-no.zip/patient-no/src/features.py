import pandas as pd
import numpy as np


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Builds the full feature matrix expected by train/predict pages.
    Uses patient-wise prior behavior, risk scores, neighbourhood frequency, etc.
    Assumes input has columns from your final cleaned file.
    """
    out = df.copy()

    # Sort to make "prior" logic consistent
    sort_cols = [c for c in ["patientid", "scheduled_day"] if c in out.columns]
    if sort_cols:
        out = out.sort_values(sort_cols).reset_index(drop=True)

    # Lead time (keep consistent even if already present)
    out["lead_time_days"] = (
        out["appointment_day"] - out["scheduled_day"]
    ).dt.days.clip(lower=0)

    # Prior appointment count
    if "patientid" in out.columns:
        out["prior_appointments"] = out.groupby("patientid").cumcount()
    else:
        # fallback: treat each row as first appointment
        out["prior_appointments"] = 0

    # Prior no-shows (use transform to align index)
    if "patientid" in out.columns:
        out["prior_noshows"] = (
            out.groupby("patientid")["no_show"]
            .transform(lambda s: s.shift(1).fillna(0).cumsum())
        )
    else:
        out["prior_noshows"] = 0

    # Prior no-show rate
    out["prior_noshow_rate"] = (
        out["prior_noshows"]
        / out["prior_appointments"].replace(0, np.nan)
    ).fillna(0)

    # Days since last appointment
    if "patientid" in out.columns:
        out["prev_appt"] = (
            out.groupby("patientid")["appointment_day"].shift(1)
        )
        out["days_since_last_appt"] = (
            (out["scheduled_day"] - out["prev_appt"]).dt.days.fillna(0)
        ).clip(lower=0)
    else:
        out["days_since_last_appt"] = 0

    # Comorbidity count
    for c in ["hypertension", "diabetes", "alcoholism", "handicap", "sms_received"]:
        if c in out.columns:
            out[c] = (
                pd.to_numeric(out[c], errors="coerce").fillna(0).astype(int)
            )
        else:
            out[c] = 0
    out["comorbidity_count"] = (
        out["hypertension"]
        + out["diabetes"]
        + out["alcoholism"]
        + out["handicap"]
    )

    # Neighbourhood frequency
    if "neighbourhood" in out.columns:
        freq = out["neighbourhood"].value_counts(dropna=False)
        out["neighbourhood_freq"] = (
            out["neighbourhood"].map(freq).fillna(0).astype(int)
        )
    else:
        out["neighbourhood_freq"] = 0

    # Risk score + interaction
    out["age"] = (
        pd.to_numeric(out.get("age", 0), errors="coerce")
        .fillna(0)
        .clip(0, 110)
    )
    out["risk_score"] = (
        out["hypertension"] * 0.6
        + out["diabetes"] * 0.6
        + out["alcoholism"] * 0.3
        + out["handicap"] * 0.4
        + (out["age"] >= 60) * 0.5
    )
    out["risk_x_leadtime"] = out["risk_score"] * out["lead_time_days"]

    # Core columns used for modeling
    core_cols = [
        "lead_time_days",
        "sms_received",
        "prior_noshow_rate",
        "days_since_last_appt",
        "comorbidity_count",
        "age",
        "neighbourhood_freq",
        "risk_x_leadtime",
        "no_show",
    ]

    missing = [c for c in core_cols if c not in out.columns]
    if missing:
        raise KeyError(f"Missing engineered columns: {missing}")

    # Keep patientid for segmentation if available
    cols = core_cols.copy()
    if "patientid" in out.columns and "patientid" not in cols:
        cols = ["patientid"] + cols

    return out[cols]
