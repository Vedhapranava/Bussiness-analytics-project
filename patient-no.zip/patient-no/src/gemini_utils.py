"""
gemini_utils.py
----------------

Utility helpers to generate *Gemini-style* explanations and
recommendations for the no-show model.

Right now this is implemented as a **rule-based explainer** so that
it works without any external API.

Later, you can:
- build a prompt with `build_prompt_from_features(...)`
- send it to a real Gemini / LLM API
- parse the response into the same dict structure.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

import pandas as pd


@dataclass
class GeminiExplanation:
    risk_level: str
    reasons: List[str]
    actions: List[str]
    raw_prompt: str | None = None
    raw_model_output: str | None = None

    def to_dict(self) -> Dict[str, object]:
        return {
            "risk_level": self.risk_level,
            "reasons": self.reasons,
            "actions": self.actions,
            "raw_prompt": self.raw_prompt,
            "raw_model_output": self.raw_model_output,
        }


# ---------------------------------------------------------------------
# 1) Prompt builder (for future real Gemini integration)
# ---------------------------------------------------------------------


def build_prompt_from_features(
    features_row: pd.DataFrame,
    proba: float,
    threshold: float = 0.5,
) -> str:
    """
    Build a text prompt that *could* be sent to a real Gemini / LLM model.

    This is not used by the rule-based explanation, but kept for future use.
    """
    row = features_row.iloc[0].to_dict()

    lines = [
        "You are an AI assistant helping a hospital reduce medical appointment no-shows.",
        "You receive engineered numeric features for a single patient appointment.",
        "",
        "Columns and values:",
    ]
    for k, v in row.items():
        lines.append(f"- {k}: {v}")

    lines.extend(
        [
            "",
            f"The trained model predicts a probability of no-show = {proba:.3f}.",
            f"The decision threshold is {threshold:.2f}.",
            "Risk is considered HIGH if probability >= threshold.",
            "",
            "TASK:",
            "1. Briefly classify the risk level as: Low, Low to moderate, "
            "Moderate to high, or Very high.",
            "2. List 3–6 bullet point reasons based on the features.",
            "3. Suggest 3–6 concrete operational actions the hospital staff "
            "should take (SMS, calls, rescheduling, prioritisation, etc.).",
            "",
            "Give the answer in three sections with headings:",
            "RISK LEVEL:",
            "REASONS:",
            "ACTIONS:",
        ]
    )

    return "\n".join(lines)


# ---------------------------------------------------------------------
# 2) Rule-based explanation (works without any API)
# ---------------------------------------------------------------------


def _rule_based_explanation(
    features_row: pd.DataFrame,
    proba: float,
    threshold: float = 0.5,
) -> GeminiExplanation:
    """
    Build a natural-language explanation and recommended actions
    from engineered feature row and predicted probability.

    This mirrors what we previously wrote inside the Gemini Assist page,
    but is now reusable.
    """
    row = features_row.iloc[0]
    reasons: List[str] = []
    actions: List[str] = []

    # --- Risk level by probability ---
    if proba >= 0.75:
        risk_level = "Very high"
        actions.append(
            "Call the patient personally and reconfirm the appointment "
            "(not only SMS)."
        )
        actions.append(
            "Offer a more convenient time slot if the patient sounds unsure."
        )
    elif proba >= 0.50:
        risk_level = "Moderate to high"
        actions.append(
            "Send a strong SMS / WhatsApp reminder 24 hours before the visit."
        )
        actions.append(
            "If possible, send one more reminder on the morning of the appointment."
        )
    elif proba >= 0.30:
        risk_level = "Low to moderate"
        actions.append(
            "Send a standard reminder SMS; no need for a call unless the slot is critical."
        )
    else:
        risk_level = "Low"
        actions.append(
            "Routine reminder SMS is sufficient; patient is likely to attend."
        )

    # --- Interpret individual features ---

    # Lead time
    lt = float(row.get("lead_time_days", 0.0))
    if lt > 30:
        reasons.append(
            f"Appointment was booked **very far in advance** "
            f"({int(lt)} days lead time), which often increases no-show risk."
        )
        actions.append(
            "Consider scheduling long lead-time patients closer to the actual date "
            "or sending multiple reminders over time."
        )
    elif lt == 0:
        reasons.append(
            "This looks like a **same-day or emergency booking** (0 days lead time)."
        )
        actions.append(
            "For same-day appointments, confirm quickly and allocate buffer slots."
        )

    # SMS
    sms = int(row.get("sms_received", 0))
    if sms == 0:
        reasons.append("No **SMS reminder** is recorded for this patient.")
        actions.append(
            "Ensure at least one SMS / WhatsApp reminder is sent and logged."
        )
    else:
        reasons.append(
            "An SMS reminder has been sent, which generally **reduces no-show risk**."
        )

    # Prior behaviour
    prior_rate = float(row.get("prior_noshow_rate", 0.0))
    if prior_rate >= 0.5:
        reasons.append(
            f"Patient has a **history of missing appointments** "
            f"(prior no-show rate ≈ {prior_rate:.2f})."
        )
        actions.append(
            "Flag this patient as high-risk in the HIS and always call 1 day before."
        )
    elif 0.2 <= prior_rate < 0.5:
        reasons.append(
            f"Patient has an **intermediate no-show history** "
            f"(prior no-show rate ≈ {prior_rate:.2f})."
        )

    # Days since last appointment
    gap = float(row.get("days_since_last_appt", 0.0))
    if gap > 90:
        reasons.append(
            f"There is a **long gap since the last appointment** "
            f"({int(gap)} days), which can reduce attachment to the hospital."
        )

    # Comorbidities
    comorbid = int(row.get("comorbidity_count", 0))
    if comorbid >= 2:
        reasons.append(
            f"Patient has **multiple comorbidities** (count = {comorbid}), "
            "which might cause health-related cancellations but also means "
            "they are clinically important to track closely."
        )
        actions.append(
            "For multi-comorbid patients, offer priority slots and easy rescheduling."
        )

    # Neighbourhood frequency
    nf = int(row.get("neighbourhood_freq", 0))
    if nf == 0:
        reasons.append(
            "Neighbourhood frequency is 0 in historical data — possibly a **new area**."
        )

    # Risk × lead time
    rxl = float(row.get("risk_x_leadtime", 0.0))
    if rxl > 10:
        reasons.append(
            "Combined **clinical risk × lead time** is high, so missing this "
            "appointment has higher medical impact."
        )
        actions.append(
            "Add this patient to a 'must attend' list and coordinate with nursing staff."
        )

    if not reasons:
        reasons.append(
            "The model prediction is based on a combination of lead time, "
            "SMS status, prior behaviour, and clinical risk factors."
        )

    # De-duplicate actions
    seen = set()
    unique_actions: List[str] = []
    for a in actions:
        if a not in seen:
            unique_actions.append(a)
            seen.add(a)

    prompt = build_prompt_from_features(features_row, proba, threshold)

    return GeminiExplanation(
        risk_level=risk_level,
        reasons=reasons,
        actions=unique_actions,
        raw_prompt=prompt,
        raw_model_output=None,  # no external model used yet
    )


# ---------------------------------------------------------------------
# 3) Public entry point
# ---------------------------------------------------------------------


def get_explanation(
    features_row: pd.DataFrame,
    proba: float,
    threshold: float = 0.5,
    use_real_model: bool = False,
) -> GeminiExplanation:
    """
    Main function to be called from Streamlit.

    Parameters
    ----------
    features_row : pd.DataFrame
        Single-row DataFrame in CORE_FEATURES order (same as used for prediction).
    proba : float
        Predicted probability of no-show.
    threshold : float, default=0.5
        Decision threshold used by the dashboard.
    use_real_model : bool, default=False
        Placeholder flag. In future, if you integrate Gemini API,
        flip this and call the real model here.

    Returns
    -------
    GeminiExplanation
        Structured explanation with risk level, reasons, actions.
    """
    # For now we always use the rule-based backend.
    # Later you can branch here:
    #
    # if use_real_model:
    #     prompt = build_prompt_from_features(features_row, proba, threshold)
    #     raw_output = call_gemini_api(prompt)
    #     return parse_gemini_output(raw_output, prompt)
    #
    return _rule_based_explanation(features_row, proba, threshold)
