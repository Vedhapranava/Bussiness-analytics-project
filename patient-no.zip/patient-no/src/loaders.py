from pathlib import Path
import pandas as pd


def load_raw() -> pd.DataFrame:
    """
    Loads KaggleV2-Cleaned.csv from project /data, standardizes columns,
    parses dates, ensures 'no_show' is int, computes lead_time_days if needed,
    and adds convenient time-based columns for Business Analytics / Time-Series.
    """
    base = Path(__file__).resolve().parents[1]
    f = base / "data" / "KaggleV2-Cleaned.csv"
    if not f.exists():
        raise FileNotFoundError(f"❌ Place KaggleV2-Cleaned.csv at: {f}")

    df = pd.read_csv(f)

    # Standardize column names
    df.columns = (
        df.columns.str.strip()
        .str.lower()
        .str.replace(" ", "_", regex=False)
        .str.replace("-", "_", regex=False)
    )

    # Required datetime columns
    for c in ("scheduled_day", "appointment_day"):
        if c in df.columns:
            df[c] = pd.to_datetime(df[c], errors="coerce")
        else:
            raise KeyError(f"Missing required datetime column: {c}")

    # Normalize target to int (already 0/1 in your file, but keep safe)
    if "no_show" not in df.columns:
        raise KeyError("Missing 'no_show' column in dataset.")
    df["no_show"] = (
        pd.to_numeric(df["no_show"], errors="coerce").fillna(0).astype(int)
    )

    # Ensure age is numeric and bounded
    if "age" in df.columns:
        df["age"] = (
            pd.to_numeric(df["age"], errors="coerce")
            .fillna(0)
            .clip(lower=0, upper=110)
        )

    # Compute lead_time_days if not present
    if "lead_time_days" not in df.columns:
        df["lead_time_days"] = (
            df["appointment_day"] - df["scheduled_day"]
        ).dt.days.clip(lower=0)

    # Extra time breakdown columns for BA + Time-Series
    if "appointment_day" in df.columns:
        df["appointment_date"] = df["appointment_day"].dt.normalize()
        df["appointment_weekday"] = df["appointment_day"].dt.day_name()
        df["appointment_hour"] = df["appointment_day"].dt.hour
        df["appointment_month"] = (
            df["appointment_day"].dt.to_period("M").astype(str)
        )

    # Trim string columns
    for col in df.select_dtypes(include="object").columns:
        df[col] = df[col].astype(str).str.strip()

    # Deduplicate
    df = df.drop_duplicates().reset_index(drop=True)
    return df
